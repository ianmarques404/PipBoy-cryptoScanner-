import requests
import pandas as pd
import urllib3
import datetime
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import time
import json
import threading # Required for running tasks in background
import traceback # To get detailed error information

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Data Class ---
class DadosConta:
    """Represents account data including address, tokens, and tag."""
    def __init__(self, endereco, tokens, address_tag):
        self.endereco = endereco
        self.tokens = tokens  # List of tuples (token_name, balance, token_abbr)
        self.address_tag = address_tag

    def __repr__(self):
        """String representation of the account data."""
        token_info = "\n".join(f"{nome} = {quantidade} ({abreviacao})"
                             for nome, quantidade, abreviacao in self.tokens)
        return (f"Dados Conta: \n"
                f"Endereço: {self.endereco}\n"
                f"Tags: {self.address_tag}\n"
                f"Tokens:\n{token_info}")

# --- Core Functions (fetch_*, format_*, process_*) ---
# These functions perform the actual data fetching and processing.
# They should remain largely unchanged and NOT interact directly with Tkinter.
def fetch_account_data(url, proxies=None):
    """Fetches account data with error handling and timeout."""
    headers = {"accept": "application/json"}
    try:
        # Make the request with or without proxies
        if proxies:
            response = requests.get(url, headers=headers, proxies=proxies, verify=False, timeout=30)
        else:
            response = requests.get(url, headers=headers, verify=False, timeout=30)
        response.raise_for_status() # Raise HTTP errors (4xx, 5xx)

        # Attempt to parse JSON response
        try:
            data = response.json()
        except json.JSONDecodeError:
            print(f"Invalid JSON response from {url}")
            return {}, "" # Return empty dict and tag for consistency

        # Try various keys for address tag, default to '--'
        address_tag = data.get("addressTag", data.get("name", "--"))
        if address_tag is None or address_tag == "": # Ensure it's not None or empty
             address_tag = "--"
        return data, str(address_tag) # Ensure tag is string

    except requests.exceptions.Timeout:
        print(f"Timeout fetching account data from {url}")
        return {}, "--"
    except requests.exceptions.RequestException as e:
        print(f"Error fetching account data from {url}: {e}")
        return {}, "--"
    except Exception as e:
        print(f"Unexpected error processing account data from {url}: {e}")
        # traceback.print_exc() # Optional: print full traceback for debugging
        return {}, "--"

def format_token_amount(amount_str, decimals):
    """
    Formats a token amount string with appropriate decimals, using dot as separator.
    Handles potential precision issues by avoiding direct float conversion where possible.
    """
    try:
        amount_str = str(amount_str) # Ensure input is a string
        decimals = int(decimals)
        if decimals < 0: decimals = 0 # Ensure decimals are non-negative

        # Calculate the integer representation of the amount based on decimals
        if '.' in amount_str:
            parts = amount_str.split('.')
            integer_part = parts[0] if parts[0] else '0' # Handle cases like '.5'
            # Take up to 'decimals' digits for fractional part, pad with zeros if needed
            fractional_part = parts[1][:decimals].ljust(decimals, '0')
            amount_int_str = integer_part + fractional_part
            amount_int = int(amount_int_str)
        else:
            # If no decimal point, treat as whole number and multiply by 10^decimals
            # Corrected logic: Convert string to int first, then multiply
            amount_int = int(amount_str) * (10 ** decimals)

        # Separate whole and fractional parts from the integer representation
        whole = str(amount_int // (10 ** decimals))
        fractional = str(amount_int % (10 ** decimals)).zfill(decimals)

        # Combine parts with a dot, if decimals > 0
        formatted_amount = f"{whole}.{fractional}" if decimals > 0 else whole

        # Clean up trailing zeros and potential trailing dot
        if '.' in formatted_amount:
            formatted_amount = formatted_amount.rstrip('0').rstrip('.')

        # Handle edge cases like "0.", "." or empty string becoming "0"
        if formatted_amount == "." or formatted_amount == "": formatted_amount = "0"
        elif formatted_amount.startswith('.'): formatted_amount = "0" + formatted_amount

        return formatted_amount
    except (ValueError, TypeError, OverflowError) as e:
        print(f"Error formatting token amount: amount='{amount_str}', decimal={decimals}. Error: {e}")
        return "Error" # Return an indicator of a formatting error

def fetch_transaction_details(hash_tx, proxies=None):
    """
    Fetches details for a transaction hash and returns a dict if it's TRX or USDT,
    otherwise returns None. Uses integer contract types. Filters for SUCCESS results.
    """
    url = f"https://apilist.tronscanapi.com/api/transaction-info?hash={hash_tx}"
    try:
        # Make request with or without proxies
        if proxies:
            response = requests.get(url, proxies=proxies, verify=False, timeout=30)
        else:
            response = requests.get(url, verify=False, timeout=30)
        response.raise_for_status()

        # Parse JSON
        try:
            data = response.json()
        except json.JSONDecodeError:
            print(f"Invalid JSON response for transaction {hash_tx}")
            return None

        # Skip failed or non-existent transactions
        if not data or data.get('contractRet') != 'SUCCESS':
            return None

        # --- Address and Tag Extraction ---
        origem = data.get("ownerAddress") or data.get("contractData", {}).get("owner_address", "--")
        destino = "--" # Default destination
        contract_data = data.get("contractData", {})
        contract_type = data.get("contractType") # Integer code (e.g., 1=TRX, 31=TRC20)

        # Determine destination based on contract type
        if contract_type == 1: # TransferContract (TRX)
            destino = contract_data.get("to_address", "--")
        elif contract_type == 2: # TransferAssetContract (TRC10)
            destino = contract_data.get("to_address", "--")
        elif contract_type == 31: # TriggerSmartContract (TRC20 or others)
            # Target contract is often the logical destination for contract interactions
            destino = data.get("contractAddress", "--")
            # If it's a TRC20 transfer, get the specific recipient
            if data.get("trc20TransferInfo") and isinstance(data["trc20TransferInfo"], list) and data["trc20TransferInfo"]:
                 trc20_info = data["trc20TransferInfo"][0]
                 if isinstance(trc20_info, dict):
                      # Override destination with the TRC20 recipient if available
                      destino = trc20_info.get("to_address", destino)
        elif data.get("toAddress"): # Fallback to general 'toAddress' field if present
            destino = data.get("toAddress")

        # Ensure addresses are strings and default to "--" if None/empty
        origem = str(origem) if origem else "--"
        destino = str(destino) if destino else "--"

        # Get address tags (names associated with addresses)
        address_tags = data.get("addressTag", {})
        nome_origem = address_tags.get(origem, "--")
        nome_destino = address_tags.get(destino, "--")
        # Ensure tags are strings and default if None/empty
        nome_origem = str(nome_origem) if nome_origem else "--"
        nome_destino = str(nome_destino) if nome_destino else "--"
        # --- End Address Extraction ---

        # Format timestamp
        timestamp_ms = data.get("timestamp", 0)
        try:
            tx_time = datetime.datetime.fromtimestamp(int(timestamp_ms) / 1000).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError, OSError):
            tx_time = "Invalid Timestamp"

        # --- Asset Identification and Filtering (Focus on TRX and USDT) ---
        asset_abbr = None
        asset_amount_str = "0"
        asset_decimals = 0
        asset_network = "Tron" # Default network

        if contract_type == 1: # TRX Transfer
            amount_sun = int(contract_data.get("amount", 0))
            if amount_sun > 0:
                asset_abbr, asset_amount_str, asset_decimals, asset_network = "TRX", str(amount_sun), 6, "Tron"

        elif contract_type == 31: # Smart Contract Call (Potentially TRC20 or TRX involved)
            # Check if TRX was sent along with the contract call
            call_value_sun = int(data.get("callValue", 0))
            if call_value_sun > 0:
                 asset_abbr, asset_amount_str, asset_decimals, asset_network = "TRX", str(call_value_sun), 6, "Tron"
            # Check if it involved a TRC20 transfer (specifically USDT)
            elif data.get("trc20TransferInfo") and isinstance(data["trc20TransferInfo"], list):
                for trc20_info in data["trc20TransferInfo"]:
                    if not isinstance(trc20_info, dict): continue
                    symbol = trc20_info.get("symbol", "").upper()
                    contract_addr = trc20_info.get("contract_address")
                    # Check for USDT by symbol OR contract address
                    usdt_contract_address = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
                    if symbol == "USDT" or contract_addr == usdt_contract_address:
                        asset_abbr = "USDT"
                        asset_amount_str = trc20_info.get("amount_str", "0")
                        asset_decimals = int(trc20_info.get("decimals", 6)) # Default USDT decimals is 6
                        asset_network = "Tron (TRC20)"
                        # Update destination and tag if different in TRC20 info
                        new_destino = trc20_info.get("to_address", destino)
                        destino = str(new_destino) if new_destino else "--"
                        nome_destino = address_tags.get(destino, "--")
                        nome_destino = str(nome_destino) if nome_destino else "--"
                        break # Found USDT, no need to check other TRC20 transfers in this TX

        elif contract_type == 2: # TRC10 Asset Transfer
            token_info = data.get("tokenInfo", {})
            if isinstance(token_info, dict):
                 token_abbr_trc10 = token_info.get("tokenAbbr", "").upper()
                 token_id_trc10 = token_info.get("tokenId")
                 # Check for USDT by abbreviation OR common TRC10 ID (less reliable)
                 usdt_trc10_id = "1002000"
                 if token_abbr_trc10 == "USDT" or token_id_trc10 == usdt_trc10_id:
                      asset_abbr = "USDT"
                      asset_amount_str = str(contract_data.get("amount", 0))
                      asset_decimals = int(token_info.get("tokenDecimal", 6)) # Default 6 if missing
                      asset_network = "Tron (TRC10)"

        # --- Return Filtered Result ---
        # Only return details if the transaction involved TRX or USDT
        if asset_abbr in ("TRX", "USDT"):
            return {
                "Origem": origem, "NomeOrigem": nome_origem,
                "Destino": destino, "NomeDestino": nome_destino,
                "Hash": hash_tx, "Ativo_Transacoes": asset_abbr,
                "Quantidade": format_token_amount(asset_amount_str, asset_decimals),
                "Data": tx_time, "Rede": asset_network
            }
        else:
            # Transaction was successful but didn't involve TRX or USDT directly in a way we track
            return None

    except requests.exceptions.Timeout:
        print(f"Timeout fetching details for hash {hash_tx}")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching details for hash {hash_tx}: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error processing details for hash {hash_tx}: {e}")
        # traceback.print_exc() # Optional for debugging
        return None

def fetch_wallet_transactions(wallet, proxies=None):
    """
    Fetches transaction hashes via Tronscan API (general transactions)
    and returns details ONLY for TRX/USDT transactions by calling fetch_transaction_details.
    """
    transaction_data = []
    start, limit, max_pages = 0, 50, 200 # Pagination settings
    print(f"Fetching Tronscan transaction list for {wallet}...")

    for page_num in range(max_pages):
        # Construct API URL for fetching transaction list
        url = f"https://apilist.tronscanapi.com/api/transaction?sort=-timestamp&count=true&limit={limit}&start={start}&address={wallet}"
        try:
            # Make request
            response = requests.get(url, headers={"accept": "application/json"}, proxies=proxies, verify=False, timeout=45)
            response.raise_for_status()
            data = response.json()
            transactions = data.get("data", [])

            # Stop if no more transactions
            if not transactions or not isinstance(transactions, list):
                break

            # Process each transaction hash in the list
            for tx in transactions:
                if isinstance(tx, dict) and tx.get("hash") and tx.get("result") == "SUCCESS":
                    # Fetch detailed info only for successful transactions
                    tx_details = fetch_transaction_details(tx.get("hash"), proxies)
                    # Add details to list if it's a relevant (TRX/USDT) transaction
                    if tx_details:
                        transaction_data.append(tx_details)

            # Prepare for next page
            start += limit
            # Stop if we've fetched all transactions according to the total count
            if data.get('total') is not None and start >= data['total']:
                break

            time.sleep(0.15) # Small delay between requests

        except (requests.exceptions.RequestException, json.JSONDecodeError, KeyError, Exception) as e:
            print(f"Error/Timeout on Tronscan page {page_num+1} for {wallet}: {e}")
            break # Stop fetching for this wallet on error
    else:
        # This block executes if the loop completes without a 'break' (i.e., max pages reached)
        print(f"Warning: Reached max pages ({max_pages}) for Tronscan {wallet}.")

    print(f"Finished Tronscan fetch for {wallet}. Found {len(transaction_data)} relevant (TRX/USDT) transactions.")
    return transaction_data

def fetch_trc20_transactions(wallet, proxies=None):
    """
    Fetch ALL TRC20 USDT transactions for a given wallet using the Trongrid API.
    This is more reliable for specifically TRC20 USDT than the general Tronscan endpoint.
    """
    transaction_data = []
    usdt_contract = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
    # Base URL for Trongrid TRC20 transactions
    base_url = f"https://api.trongrid.io/v1/accounts/{wallet}/transactions/trc20"
    params = {
        "limit": 200, # Max limit per page
        "only_confirmed": "true",
        "contract_address": usdt_contract
    }
    headers = {"accept": "application/json"}
    print(f"Fetching Trongrid TRC20 USDT transactions for {wallet}...")
    page_count, max_pages = 0, 100 # Limit number of pages to prevent infinite loops
    next_page_url = base_url # Start with base URL

    while next_page_url and page_count < max_pages:
        page_count += 1
        print(f"  Fetching Trongrid page {page_count}...")
        current_url = next_page_url # URL for this iteration

        try:
            # Make request (using params only for the first request, then rely on 'next' link)
            if page_count == 1:
                 response = requests.get(current_url, headers=headers, params=params, proxies=proxies, verify=False, timeout=45)
            else:
                 response = requests.get(current_url, headers=headers, proxies=proxies, verify=False, timeout=45)

            response.raise_for_status()
            data = response.json()

            success = data.get("success", False)
            current_page_txs = data.get("data", [])

            # Stop if API indicates failure or no data
            if not success or not current_page_txs:
                 if not success: print(f"  Trongrid API reported failure (success=false) on page {page_count}.")
                 break
            if not isinstance(current_page_txs, list):
                 print(f"  Trongrid API returned non-list data on page {page_count}.")
                 break

            # Process transactions from the current page
            for tx in current_page_txs:
                if not isinstance(tx, dict): continue

                # Double-check it's USDT (Trongrid endpoint should already filter, but good practice)
                token_info = tx.get("token_info", {})
                if not isinstance(token_info, dict) or token_info.get("symbol", "").upper() != "USDT":
                    continue

                # Extract transaction details
                tx_id = tx.get("transaction_id", "--")
                value_str = tx.get("value", "0")
                decimals = int(token_info.get("decimals", 6)) # USDT uses 6 decimals
                timestamp_ms = tx.get("block_timestamp", 0)
                try:
                    tx_time = datetime.datetime.fromtimestamp(int(timestamp_ms) / 1000).strftime('%Y-%m-%d %H:%M:%S')
                except (ValueError, TypeError, OSError):
                    tx_time = "Invalid Timestamp"

                # Append formatted data
                transaction_data.append({
                    "Origem": tx.get("from", "--"), "NomeOrigem": "--", # Trongrid doesn't provide tags
                    "Destino": tx.get("to", "--"), "NomeDestino": "--",
                    "Hash": tx_id, "Ativo_Transacoes": "USDT",
                    "Quantidade": format_token_amount(value_str, decimals),
                    "Data": tx_time, "Rede": "Tron (TRC20)"
                })

            # Get the URL for the next page from the 'meta' section
            meta = data.get("meta", {})
            links = meta.get("links", {}) if isinstance(meta, dict) else {}
            next_page_url = links.get("next") if isinstance(links, dict) else None

            # Small delay if there's a next page
            if next_page_url:
                time.sleep(0.2)

        except (requests.exceptions.RequestException, json.JSONDecodeError, KeyError, Exception) as e:
            print(f"Error/Timeout on Trongrid page {page_count} for {wallet}: {e}")
            next_page_url = None # Stop pagination on error

    else:
        # This block executes if the loop finishes because max_pages was reached
        if page_count >= max_pages:
            print(f"Warning: Reached max pages ({max_pages}) for Trongrid {wallet}.")

    print(f"Finished Trongrid fetch for {wallet}. Found {len(transaction_data)} transactions.")
    return transaction_data

def create_temp_wallets_from_transactions(transactions_df, original_addresses, temp_wallets_file_path):
    """
    Creates temp_wallets.xlsx containing unique addresses found in transactions
    that were NOT in the original input list. Filters for valid Tron addresses.
    """
    # Handle empty or invalid input DataFrame
    if transactions_df is None or transactions_df.empty:
        print("Transaction data frame is empty, cannot create temp wallets file.")
        # Create an empty file to avoid errors later if it's expected
        pd.DataFrame(columns=['Endereços']).to_excel(temp_wallets_file_path, index=False)
        return

    required_cols = ['Origem', 'Destino']
    if not all(col in transactions_df.columns for col in required_cols):
        print(f"Warning: Transaction DataFrame missing required columns {required_cols}. Cannot create temp wallets.")
        pd.DataFrame(columns=['Endereços']).to_excel(temp_wallets_file_path, index=False)
        return

    # Extract unique addresses from 'Origem' and 'Destino' columns
    orig_addr = transactions_df['Origem'].dropna().astype(str)
    dest_addr = transactions_df['Destino'].dropna().astype(str)
    all_addrs = pd.concat([orig_addr, dest_addr]).unique()

    # Filter for valid Tron addresses (start with 'T', 34 chars)
    valid_addresses = {addr for addr in all_addrs if isinstance(addr, str) and addr.startswith('T') and len(addr) == 34}

    # Find addresses present in transactions but not in the original input
    related_addresses = valid_addresses - original_addresses

    # Create DataFrame and save to Excel
    temp_wallets_df = pd.DataFrame(list(related_addresses), columns=['Endereços'])
    try:
        temp_wallets_df.to_excel(temp_wallets_file_path, index=False)
        print(f"Created temp wallets file: {os.path.basename(temp_wallets_file_path)} ({len(related_addresses)} related addresses found)")
    except Exception as e:
        print(f"ERROR saving temp wallets file '{temp_wallets_file_path}': {e}")

def mark_original_addresses(df, original_addresses):
    """Adds a 'Consultado' column marking if 'Endereço' was in the original input set."""
    if df is None or df.empty or 'Endereço' not in df.columns:
        # Return the DataFrame as is (or an empty one) if invalid
        return df if df is not None else pd.DataFrame()

    original_set = set(original_addresses) # Use set for efficient lookup
    # Apply function to check membership in the original set
    df['Consultado'] = df['Endereço'].apply(lambda x: "Sim" if x in original_set else "Não")
    return df

def process_account_balances(address, proxies=None):
    """
    Processes current balances ONLY for TRX and USDT (TRC20) for a given address.
    Fetches account data and extracts relevant balances.
    """
    token_info_list = [] # To store (token_name, balance, token_abbr) tuples
    print(f"  Fetching balance for {address}...")

    # Fetch general account info (includes TRX balance and TRC20 list)
    account_url = f"https://apilist.tronscanapi.com/api/account?address={address}"
    account_data, address_tag = fetch_account_data(account_url, proxies)

    # Handle cases where account data couldn't be fetched
    if not account_data:
        print(f"  No account data found for {address}.")
        # Return a default object indicating no tokens found
        return DadosConta(endereco=address, tokens=[], address_tag=address_tag or "--")

    # --- TRX Balance ---
    balance_sun_str = str(account_data.get('balance', 0)) # Balance is in SUN (1 TRX = 1,000,000 SUN)
    try:
        # Only process if balance is greater than 0
        if int(balance_sun_str) > 0:
            formatted_trx = format_token_amount(balance_sun_str, 6) # TRX has 6 decimals
            if formatted_trx != "Error":
                token_info_list.append(("Tron", formatted_trx, "TRX"))
            else:
                token_info_list.append(("Tron", "Format Error", "TRX"))
    except (ValueError, TypeError):
        print(f"  Invalid TRX balance value '{balance_sun_str}' for {address}")

    # --- USDT Balance (TRC20) ---
    trc20_tokens = account_data.get('trc20token_balances', [])
    usdt_contract_address = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"

    if isinstance(trc20_tokens, list):
        for token in trc20_tokens:
            if not isinstance(token, dict): continue # Skip invalid entries

            # Check if the token is USDT by its contract address (tokenId)
            token_id = token.get('tokenId') or token.get('token_id') # API uses both keys sometimes
            if token_id == usdt_contract_address:
                balance_str = str(token.get('balance', '0')) # Token balance string
                # Get decimals, default to 6 for USDT if missing
                decimals = int(token.get('tokenDecimal') or token.get('decimals', 6))
                token_name = token.get('tokenName') or token.get('name') or "Tether USD" # Get token name
                token_symbol = token.get('tokenAbbr') or token.get('symbol') or "USDT" # Get symbol

                # Format the balance
                formatted_usdt = format_token_amount(balance_str, decimals)
                if formatted_usdt != "Error":
                    token_info_list.append((token_name, formatted_usdt, token_symbol))
                else:
                     token_info_list.append((token_name, "Format Error", token_symbol))
                break # Found USDT, no need to check other TRC20 tokens

    # If no TRX or USDT balance was found after checking, add a placeholder
    if not token_info_list:
         print(f"  No relevant TRX or USDT balance found for {address}.")
         # Add a placeholder to indicate the address was processed but had no relevant balance
         token_info_list.append(("N/A", "0", "N/A"))

    # Return the structured data
    return DadosConta(endereco=address, tokens=token_info_list, address_tag=address_tag)

# --- Tkinter Dialog Functions ---

def create_progress_window(parent=None):
    """Creates a modal progress window (Toplevel) centered on the parent."""
    progress_window = tk.Toplevel(parent)
    progress_window.title("Processando...")
    progress_window.geometry("450x180")
    progress_window.resizable(False, False)
    # Disable the close button while processing
    progress_window.protocol("WM_DELETE_WINDOW", lambda: None)

    # Center the progress window relative to the parent window
    if parent:
        parent.update_idletasks() # Ensure parent dimensions are up-to-date
        # Get parent window geometry
        px, py = parent.winfo_rootx(), parent.winfo_rooty()
        pw, ph = parent.winfo_width(), parent.winfo_height()
        # Get progress window dimensions
        w, h = 450, 180
        # Calculate position
        x = px + (pw // 2) - (w // 2)
        y = py + (ph // 2) - (h // 2)
        progress_window.geometry(f'+{x}+{y}')

    # Make the window modal (grab focus)
    progress_window.transient(parent)
    progress_window.grab_set()

    # --- Widgets inside the progress window ---
    # Status label (e.g., "Processing Original Addresses...")
    status_label = tk.Label(progress_window, text="Iniciando...", font=("Arial", 12))
    status_label.pack(pady=10)
    # Label to show the current wallet being processed
    wallet_label = tk.Label(progress_window, text="", font=("Arial", 10), wraplength=430) # Wrap long addresses
    wallet_label.pack(pady=5)
    # Progress bar
    progress_bar = ttk.Progressbar(progress_window, orient="horizontal", length=400, mode="determinate")
    progress_bar.pack(pady=10)
    # Label for overall progress (e.g., "Original: 5/20")
    overall_label = tk.Label(progress_window, text="", font=("Arial", 10))
    overall_label.pack(pady=5)

    # Return the window and its key widgets for updating
    return progress_window, status_label, wallet_label, progress_bar, overall_label

def show_proxy_dialog(parent=None):
    """Shows a simple dialog asking the user to choose proxy settings."""
    # Create a Toplevel window for the dialog
    dialog = tk.Toplevel(parent)
    dialog.title("Configuração de Proxy")
    dialog.geometry("350x180")
    dialog.resizable(False, False)

    # Center the dialog relative to the parent
    if parent:
        parent.update_idletasks()
        px, py = parent.winfo_rootx(), parent.winfo_rooty()
        pw, ph = parent.winfo_width(), parent.winfo_height()
        dialog.geometry(f'+{px + (pw // 2) - 175}+{py + (ph // 2) - 90}')

    # Make it topmost and modal
    dialog.attributes("-topmost", True)
    dialog.transient(parent)
    dialog.grab_set()

    # Label
    tk.Label(dialog, text="Selecione a configuração de proxy:", font=("Arial", 12)).pack(pady=20)

    # Variable to store the user's choice
    choice = tk.StringVar(value="cancel") # Default to cancel if closed

    # Frame for buttons
    btn_frame = tk.Frame(dialog)
    btn_frame.pack(pady=10)

    # Function to set choice and close dialog
    def set_choice(val):
        choice.set(val)
        dialog.destroy()

    # Handle closing the dialog window
    dialog.protocol("WM_DELETE_WINDOW", lambda: set_choice("cancel"))

    # Buttons
    tk.Button(btn_frame, text="Usar Proxy", command=lambda: set_choice("proxy"), width=15).pack(side=tk.LEFT, padx=5)
    tk.Button(btn_frame, text="Sem Proxy", command=lambda: set_choice("no_proxy"), width=15).pack(side=tk.LEFT, padx=5)
    tk.Button(btn_frame, text="Cancelar", command=lambda: set_choice("cancel"), width=15).pack(side=tk.LEFT, padx=5)

    # Wait for the dialog to be closed (user makes a choice)
    dialog.wait_window()
    return choice.get() # Return the selected value ('proxy', 'no_proxy', or 'cancel')

def get_proxy_credentials(parent=None):
    """
    Gets proxy username and password using simpledialog.
    Standard simpledialog should grab focus automatically.
    """
    while True:
        # Ask for username
        user = simpledialog.askstring("Proxy", "Usuário:", parent=parent)
        if user is None: return None # User cancelled

        # Ask for password (masked)
        # This dialog should grab focus automatically when it appears
        pwd = simpledialog.askstring("Proxy", "Senha:", show='*', parent=parent)
        if pwd is None: return None # User cancelled

        # Check if both are provided
        if not user or not pwd:
            # Ask if user wants to retry if fields are empty
            if not messagebox.askretrycancel("Erro", "Usuário e Senha são necessários.", parent=parent):
                return None # User chose not to retry
            # If retry, the loop continues
        else:
            # Both provided, format the proxy URL
            # Assumes a specific proxy server address and port
            return f"http://{user}:{pwd}@proxy.dpf.gov.br:8080"

# --- Main Tkinter Application Class ---
class TronScannerApp:
    """Main GUI application class for the Tron Scan Tool."""
    def __init__(self, master):
        self.master = master # The root Tkinter window
        self.input_file_path = None # Path to the selected input Excel file
        self.output_dir = None # Path to the selected output directory
        self.proxies = None # Dictionary for requests proxies, or None
        self.processing_thread = None # Holds the background processing thread
        # Widgets for the progress window (initialized when processing starts)
        self.progress_window = None
        self.status_label = None
        self.wallet_label = None
        self.progress_bar = None
        self.overall_progress_label = None

        # --- Main Window Setup ---
        master.title("Tron Scan")
        master.geometry("600x300") # Adjusted size for better layout
        master.resizable(False, False)
        # Center the main window on the screen
        master.update_idletasks()
        screen_width = master.winfo_screenwidth()
        screen_height = master.winfo_screenheight()
        window_width = master.winfo_width()
        window_height = master.winfo_height()
        x_coord = (screen_width // 2) - (window_width // 2)
        y_coord = (screen_height // 2) - (window_height // 2)
        master.geometry(f'+{x_coord}+{y_coord}')

        # --- Instructions Area ---
        instruction_frame = tk.Frame(master, bd=2, relief="groove")
        instruction_frame.pack(pady=10, padx=10, fill="x")
        # ** Instructions include 'Sheet1' **
        instruction_text = (
            "Bem vindo ao TronScan!\n\n"
            "1. Escolha a planilha Excel (.xlsx) com endereços Tron (coluna 'Endereços', planilha 'Planilha1' ou 'Sheet1').\n"
            "2. Escolha o diretório onde os arquivos de saída (Saldo.xlsx, Transacoes.xlsx) serão salvos.\n"
            "3. Clique em 'Executar Script'.\n"
            "4. Escolha sua configuração de proxy.\n"
            "5. Carregue os arquivos no DashBoard."
        )
        tk.Label(instruction_frame, text=instruction_text, justify=tk.LEFT, wraplength=560).pack(pady=5, padx=5)

        # --- Input File Selection Area ---
        self.file_frame = tk.Frame(master)
        self.file_frame.pack(pady=5, padx=10, fill="x")
        # Button to open file dialog
        self.select_button = tk.Button(self.file_frame, text="Selecionar Arquivo (.xlsx)", command=self.select_input_file, width=25)
        self.select_button.pack(side=tk.LEFT, padx=(0, 5))
        # Entry to display selected file path (read-only)
        self.file_path_var = tk.StringVar(value="Nenhum arquivo selecionado")
        self.file_path_entry = tk.Entry(self.file_frame, textvariable=self.file_path_var, state='readonly', width=50)
        self.file_path_entry.pack(side=tk.LEFT, fill="x", expand=True)

        # --- Output Directory Selection Area ---
        self.output_dir_frame = tk.Frame(master)
        self.output_dir_frame.pack(pady=5, padx=10, fill="x")
        # Button to open directory dialog
        self.select_output_dir_button = tk.Button(self.output_dir_frame, text="Selecionar Diretório Saída", command=self.select_output_directory, width=25)
        self.select_output_dir_button.pack(side=tk.LEFT, padx=(0, 5))
        # Entry to display selected directory path (read-only)
        self.output_dir_var = tk.StringVar(value="Nenhum diretório selecionado")
        self.output_dir_entry = tk.Entry(self.output_dir_frame, textvariable=self.output_dir_var, state='readonly', width=50)
        self.output_dir_entry.pack(side=tk.LEFT, fill="x", expand=True)

        # --- Execute Button Area ---
        execute_frame = tk.Frame(master)
        execute_frame.pack(pady=15)
        # Button to start the process (initially disabled)
        self.execute_button = tk.Button(execute_frame, text="Executar Script", command=self.start_execution, state='disabled', width=20, height=2)
        self.execute_button.pack()

    def check_execute_button_state(self):
        """Enable execute button only if both input file and output dir are selected."""
        if self.input_file_path and self.output_dir:
            self.execute_button.config(state='normal')
        else:
            self.execute_button.config(state='disabled')

    def select_input_file(self):
        """Handles input Excel file selection and validation."""
        # Open file dialog for .xlsx files
        temp_path = filedialog.askopenfilename(
            title="Selecionar Arquivo Excel (.xlsx)",
            filetypes=[("Arquivos Excel", "*.xlsx")],
            parent=self.master
        )
        # If user cancels, do nothing
        if not temp_path:
            return

        # Validate the selected file
        is_valid, error_message = self.validate_input_file(temp_path)
        if not is_valid:
            # Show error if validation fails
            messagebox.showerror("Erro no Arquivo", error_message, parent=self.master)
            self.input_file_path = None
            self.file_path_var.set("Falha na validação!")
        else:
            # Update path if valid
            self.input_file_path = temp_path
            self.file_path_var.set(os.path.basename(self.input_file_path)) # Show only filename
            print(f"Input file selected: {self.input_file_path}")

        # Update the state of the execute button
        self.check_execute_button_state()

    def select_output_directory(self):
        """Handles output directory selection."""
        # Open directory selection dialog
        temp_dir = filedialog.askdirectory(
            title="Selecionar Diretório de Saída",
            parent=self.master
        )
        # If user cancels, do nothing
        if not temp_dir:
            return

        # Update output directory path
        self.output_dir = temp_dir
        self.output_dir_var.set(self.output_dir)
        print(f"Output directory selected: {self.output_dir}")

        # Update the state of the execute button
        self.check_execute_button_state()

    def validate_input_file(self, file_path):
        """
        Validates the selected Excel file structure.
        Checks for .xlsx extension, existence of 'Planilha1' or 'Sheet1',
        and the 'Endereços' column within the found sheet.
        """
        # Check extension
        if not file_path.lower().endswith(".xlsx"):
            return False, "O arquivo selecionado não é um .xlsx."

        try:
            # Read the Excel file structure without loading all data initially
            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names

            # ** MODIFIED: Check for 'Planilha1' or 'Sheet1' (case-insensitive for Sheet1) **
            target_sheet = None
            if 'Planilha1' in sheet_names:
                target_sheet = 'Planilha1'
            else:
                # Check for 'Sheet1' case-insensitively
                for name in sheet_names:
                    if name.lower() == 'sheet1':
                        target_sheet = name # Use the actual name found (e.g., 'Sheet1' or 'sheet1')
                        break

            # If neither sheet is found
            if target_sheet is None:
                return False, "Nenhuma planilha chamada 'Planilha1' ou 'Sheet1' foi encontrada no arquivo."

            # Read the found sheet to check for the column
            df = pd.read_excel(excel_file, sheet_name=target_sheet)
            if 'Endereços' not in df.columns:
                return False, f"Coluna 'Endereços' não encontrada na planilha '{target_sheet}'."

            # If all checks pass
            return True, None

        except FileNotFoundError:
            return False, f"Arquivo não encontrado:\n{file_path}"
        except Exception as e:
            # Catch other potential errors during file reading/validation
            print(f"Validation Error reading {file_path}: {type(e).__name__} - {e}")
            return False, f"Erro ao ler ou validar o arquivo Excel:\n{type(e).__name__}"

    def start_execution(self):
        """
        Starts the process: checks prerequisites, asks for proxy,
        and launches the background processing thread.
        """
        # Prevent starting if already running
        if self.processing_thread and self.processing_thread.is_alive():
            messagebox.showwarning("Em Andamento", "Um processo já está em execução.", parent=self.master)
            return

        # Ensure output directory and input file are selected
        if not self.output_dir:
             messagebox.showerror("Erro", "Por favor, selecione um diretório de saída.", parent=self.master)
             return
        if not self.input_file_path:
             messagebox.showerror("Erro", "Por favor, selecione um arquivo de entrada válido.", parent=self.master)
             return

        # Disable UI elements during processing
        self.select_button.config(state='disabled')
        self.select_output_dir_button.config(state='disabled')
        self.execute_button.config(state='disabled')

        # Ask user about proxy settings
        choice = show_proxy_dialog(parent=self.master)

        # Handle proxy choice
        if choice == "cancel":
            messagebox.showinfo("Cancelado", "Operação cancelada.", parent=self.master)
            self.reset_ui_state() # Re-enable UI if cancelled
            return

        self.proxies = None # Reset proxies
        if choice == "proxy":
            # Get proxy credentials if 'Use Proxy' was chosen
            proxy_url = get_proxy_credentials(parent=self.master)
            if not proxy_url:
                # User cancelled credential input
                messagebox.showinfo("Cancelado", "Configuração de proxy cancelada.", parent=self.master)
                self.reset_ui_state()
                return
            # Set up proxy dictionary for requests
            self.proxies = {'http': proxy_url, 'https': proxy_url}
            print("Proxy configurado.")
        else:
            # 'No Proxy' was chosen
            print("Executando sem proxy.")

        # Create and show the progress window
        self.progress_window, self.status_label, self.wallet_label, self.progress_bar, self.overall_progress_label = create_progress_window(parent=self.master)

        # Start the background thread for the main processing logic
        self.processing_thread = threading.Thread(
            target=self._run_processing_logic,
            # Pass necessary arguments to the thread's target function
            args=(self.input_file_path, self.proxies, self.output_dir),
            daemon=True # Allows main program to exit even if thread is running
        )
        self.processing_thread.start()

    def reset_ui_state(self):
        """Resets UI buttons to their normal state after processing or cancellation."""
        # Check if the main window still exists before trying to configure widgets
        # This prevents errors if the window was closed (e.g., by auto-close)
        if self.master and hasattr(self.master, 'winfo_exists') and self.master.winfo_exists():
            self.select_button.config(state='normal')
            self.select_output_dir_button.config(state='normal')
            # Re-enable execute button only if selections are still valid
            self.check_execute_button_state()
        # Clear reference to the progress window if it existed
        self.progress_window = None

    def _update_progress(self, status=None, wallet=None, overall=None, value=None, max_value=None):
        """
        Safely updates progress window widgets from the background thread
        using root.after to schedule updates on the main GUI thread.
        """
        # Check if the progress window and the master window still exist
        if not self.progress_window or not hasattr(self.progress_window, 'winfo_exists') or not self.progress_window.winfo_exists():
            return
        if not self.master or not hasattr(self.master, 'winfo_exists') or not self.master.winfo_exists():
            return

        # Use master.after(0, ...) to queue the UI update for the main thread
        if status is not None:
            self.master.after(0, lambda s=status: self.status_label.config(text=s))
        if wallet is not None:
            self.master.after(0, lambda w=wallet: self.wallet_label.config(text=w))
        if overall is not None:
            self.master.after(0, lambda o=overall: self.overall_progress_label.config(text=o))
        if max_value is not None:
             self.master.after(0, lambda m=max_value: self.progress_bar.config(maximum=m))
        if value is not None:
            self.master.after(0, lambda v=value: self.progress_bar.config(value=v))

    def _show_final_message(self, title, message, is_error=False):
        """
        Safely shows the final message box (info or error) from the background thread
        and triggers cleanup *after* the message box is closed.
        Uses root.after for thread safety.
        """
        # Check if master window exists before queuing
        if not self.master or not hasattr(self.master, 'winfo_exists') or not self.master.winfo_exists():
            print("Master window closed before final message could be shown.")
            return

        # Queue the message box display and subsequent cleanup
        self.master.after(0, lambda: [
            # Show the appropriate message box
            messagebox.showerror(title, message, parent=self.master) if is_error else messagebox.showinfo(title, message, parent=self.master),
            # Trigger cleanup *after* the user closes the message box
            self._cleanup_after_processing()
        ])

    def _cleanup_after_processing(self):
        """
        Destroys the progress window (if it exists) and closes the main application window.
        """
        # Safely destroy the progress window
        if self.progress_window and hasattr(self.progress_window, 'winfo_exists') and self.progress_window.winfo_exists():
            try:
                self.progress_window.destroy()
            except tk.TclError:
                # Ignore error if window is already destroyed
                pass
            self.progress_window = None # Clear reference

        print("Processamento finalizado. Fechando aplicação.")
        # ** MODIFIED: Re-enabled closing the main window **
        # Check if master window exists before destroying
        if self.master and hasattr(self.master, 'winfo_exists') and self.master.winfo_exists():
            self.master.destroy() # Close the main window


    def _run_processing_logic(self, input_path, current_proxies, output_path_base):
        """
        Core processing logic running in the background thread.
        Reads addresses, fetches balances and transactions, saves results.
        """
        # Define output file paths based on the selected directory
        output_file_balances = os.path.join(output_path_base, "Saldo.xlsx")
        output_file_transactions = os.path.join(output_path_base, "Transacoes.xlsx")
        temp_wallets_file = os.path.join(output_path_base, "temp_wallets_internal.xlsx") # Use a distinct name

        try:
            # --- 1. Read and Validate Input Addresses ---
            self._update_progress(status="Lendo endereços do arquivo de entrada...", value=0, max_value=100)

            # ** MODIFIED: Read from 'Planilha1' or 'Sheet1' **
            try:
                # Try reading 'Planilha1' first
                addresses_df = pd.read_excel(input_path, sheet_name='Planilha1')
                print("Lendo dados da planilha 'Planilha1'.")
            except ValueError: # pandas raises ValueError if sheet not found
                try:
                    # If 'Planilha1' is not found, try reading 'Sheet1' (case-insensitive handled by pandas)
                    addresses_df = pd.read_excel(input_path, sheet_name='Sheet1')
                    print("Lendo dados da planilha 'Sheet1'.")
                except ValueError:
                    # If neither is found, raise a specific error
                    raise ValueError(f"Não foi possível encontrar a planilha 'Planilha1' ou 'Sheet1' em {os.path.basename(input_path)}.")

            # Validate 'Endereços' column exists (already done in validate_input_file, but good to double-check)
            if 'Endereços' not in addresses_df.columns:
                 raise ValueError("Coluna 'Endereços' não encontrada na planilha lida.")

            # Clean and filter addresses
            addresses_df = addresses_df.dropna(subset=['Endereços']) # Remove rows with no address
            addresses_df['Endereços'] = addresses_df['Endereços'].astype(str).str.strip() # Ensure string and remove whitespace
            # Filter using regex for valid Tron address format
            addresses_df = addresses_df[addresses_df['Endereços'].str.match(r'^T[a-km-zA-HJ-NP-Z1-9]{33}$', na=False)]
            original_addresses = set(addresses_df['Endereços'].tolist()) # Get unique valid addresses

            if not original_addresses:
                raise ValueError(f"Nenhum endereço Tron válido encontrado no arquivo '{os.path.basename(input_path)}'.")

            print(f"Processando {len(original_addresses)} endereços válidos do arquivo de entrada...")
            all_transactions, balance_results, processed_addresses = [], [], set()
            total_original = len(original_addresses)
            self._update_progress(max_value=total_original) # Set progress bar max for original addresses

            # --- 2. Process Original Addresses (Balances and Transactions) ---
            self._update_progress(status="Processando Endereços Originais...")
            for i, address in enumerate(original_addresses):
                processed_count = i + 1
                # Update progress bar and labels
                self._update_progress(
                    wallet=f"Consultando: {address}",
                    overall=f"Original: {processed_count}/{total_original}",
                    value=processed_count
                )

                # Fetch transactions (Tronscan + Trongrid for robustness)
                wallet_txs = fetch_wallet_transactions(address, current_proxies)
                all_transactions.extend(wallet_txs)
                trc20_usdt_txs = fetch_trc20_transactions(address, current_proxies)
                all_transactions.extend(trc20_usdt_txs)

                # Fetch current balance (TRX and USDT)
                dados_conta = process_account_balances(address, current_proxies)
                if dados_conta:
                    balance_results.append(dados_conta)

                processed_addresses.add(address) # Mark as processed
                time.sleep(0.2) # Small delay between addresses

            # --- 3. Process and Save Transactions ---
            self._update_progress(status="Gerando Arquivo de Transações...", value = 0, wallet="", overall="", max_value=100)
            transactions_df = None
            if not all_transactions:
                print("Nenhuma transação TRX ou USDT encontrada para os endereços originais.")
                # Create empty DataFrame with correct columns if no transactions found
                transactions_df = pd.DataFrame(columns=["Data", "Origem", "NomeOrigem", "Destino", "NomeDestino", "Ativo_Transacoes", "Quantidade", "Rede", "Hash", "Original Origem", "Original Destino"])
            else:
                # Create DataFrame from collected transaction data
                transactions_df = pd.DataFrame(all_transactions)
                # Remove duplicate transactions based on hash (can occur if fetched from both APIs)
                transactions_df = transactions_df.drop_duplicates(subset=['Hash'], keep='first')

                # Mark if Origin/Destination were in the original input list
                transactions_df['Original Origem'] = transactions_df['Origem'].apply(lambda x: "Sim" if x in original_addresses else "Não")
                transactions_df['Original Destino'] = transactions_df['Destino'].apply(lambda x: "Sim" if x in original_addresses else "Não")

                # Define and enforce column order
                cols_order = ["Data", "Origem", "NomeOrigem", "Destino", "NomeDestino", "Ativo_Transacoes", "Quantidade", "Rede", "Hash", "Original Origem", "Original Destino"]
                # Add missing columns if any (e.g., if no tags were found)
                for col in cols_order:
                    if col not in transactions_df.columns:
                        transactions_df[col] = None # Add column with None values
                transactions_df = transactions_df[cols_order] # Reorder columns

                # Format and sort by date
                transactions_df['Data'] = pd.to_datetime(transactions_df['Data'], errors='coerce') # Convert to datetime, handle errors
                transactions_df = transactions_df.sort_values(by="Data", ascending=False, na_position='last') # Sort newest first
                # Convert date back to string format, fill errors
                transactions_df['Data'] = transactions_df['Data'].dt.strftime('%Y-%m-%d %H:%M:%S').fillna("Invalid Date")
                # Fill missing tags with '--'
                transactions_df[['NomeOrigem', 'NomeDestino']] = transactions_df[['NomeOrigem', 'NomeDestino']].fillna("--")

            # Save transactions to Excel
            try:
                transactions_df.to_excel(output_file_transactions, index=False)
                print(f"Saved {len(transactions_df) if transactions_df is not None else 0} unique transactions to {os.path.basename(output_file_transactions)}")
            except Exception as e:
                # Raise a more specific error if saving fails
                raise IOError(f"Falha ao salvar o arquivo de transações '{os.path.basename(output_file_transactions)}': {e}")

            # --- 4. Identify and Process Related Addresses (Balances Only) ---
            # Create the temp file listing addresses found in transactions but not in original input
            create_temp_wallets_from_transactions(transactions_df, original_addresses, temp_wallets_file)

            self._update_progress(status="Processando Endereços Relacionados (Saldos)...", value=0, max_value=100)
            related_addresses = set()
            try:
                # Read the temp file if it was created and exists
                if os.path.exists(temp_wallets_file):
                     temp_wallets_df = pd.read_excel(temp_wallets_file)
                     # Clean and validate addresses from the temp file
                     temp_wallets_df = temp_wallets_df.dropna(subset=['Endereços'])
                     temp_wallets_df['Endereços'] = temp_wallets_df['Endereços'].astype(str).str.strip()
                     temp_wallets_df = temp_wallets_df[temp_wallets_df['Endereços'].str.match(r'^T[a-km-zA-HJ-NP-Z1-9]{33}$', na=False)]
                     # Get unique related addresses that haven't been processed yet
                     related_addresses = set(temp_wallets_df['Endereços'].tolist()) - processed_addresses
            except Exception as e:
                 # Log a warning if reading the temp file fails, but continue
                 print(f"Warning: Error reading temporary related wallets file: {e}")

            total_related = len(related_addresses)
            print(f"Found {total_related} new related addresses to check balances for.")
            if total_related > 0:
                self._update_progress(max_value=total_related) # Update progress bar max
                self._update_progress(overall=f"Relacionados: 0/{total_related}")
                for i, address in enumerate(related_addresses):
                    processed_related_count = i + 1
                    # Update progress
                    self._update_progress(
                        wallet=f"Consultando: {address}",
                        overall=f"Relacionados: {processed_related_count}/{total_related}",
                        value=processed_related_count
                    )
                    # Fetch balance only for related addresses
                    dados_conta = process_account_balances(address, current_proxies)
                    if dados_conta:
                        balance_results.append(dados_conta)
                    processed_addresses.add(address) # Mark as processed
                    time.sleep(0.2) # Small delay

            # --- 5. Prepare and Save Final Balance Output ---
            self._update_progress(status="Gerando Arquivo de Saldos...", value=0, wallet="", overall="", max_value=100)
            balance_rows = []
            # Keep track of the best tag found for each address
            address_tags_map = {}

            # Process collected balance data
            for dados in balance_results:
                 # Update tag map: prioritize non-'--' tags found during balance check
                 current_tag = address_tags_map.get(dados.endereco, "--")
                 if dados.address_tag and dados.address_tag != '--':
                      address_tags_map[dados.endereco] = dados.address_tag
                 # If no tag yet and balance check found one, use it (even if '--')
                 elif current_tag == '--' and dados.address_tag:
                      address_tags_map[dados.endereco] = dados.address_tag

                 # Add rows for actual balances (ignore the 'N/A' placeholder)
                 if dados.tokens:
                      for _, balance, token_abbr in dados.tokens:
                           if token_abbr != 'N/A': # Don't add the placeholder row
                                balance_rows.append([dados.endereco, balance, token_abbr])

            # Create initial balance DataFrame
            if not balance_rows:
                # Handle case with no balances found at all
                output_df = pd.DataFrame(columns=['Endereço', 'Saldo', 'Ativo_Saldo'])
            else:
                output_df = pd.DataFrame(balance_rows, columns=['Endereço', 'Saldo', 'Ativo_Saldo'])
                # Remove duplicates that might arise if an address was processed twice (shouldn't happen with sets, but safe)
                output_df = output_df.drop_duplicates(subset=['Endereço', 'Ativo_Saldo'], keep='first')

            # --- Consolidate Tags and Add Missing Addresses ---
            # Get all addresses involved (original + processed + from transactions)
            all_relevant_addresses = original_addresses.union(processed_addresses)
            if transactions_df is not None and not transactions_df.empty:
                 all_relevant_addresses.update(transactions_df['Origem'].dropna().unique())
                 all_relevant_addresses.update(transactions_df['Destino'].dropna().unique())
                 # Filter again for valid Tron format after combining all sources
                 all_relevant_addresses = {addr for addr in all_relevant_addresses if isinstance(addr, str) and addr.startswith('T') and len(addr) == 34}

            # Find addresses that are relevant but missing from the balance results (likely have 0 balance)
            missing_addresses = all_relevant_addresses - set(output_df['Endereço'].unique())
            if missing_addresses:
                 # Create rows for missing addresses with 0 balance / N/A asset
                 missing_df = pd.DataFrame({'Endereço': list(missing_addresses), 'Saldo': '0', 'Ativo_Saldo': 'N/A'})
                 # Append these rows to the main balance DataFrame
                 output_df = pd.concat([output_df, missing_df], ignore_index=True)

            # Consolidate tags from balance checks and transaction details
            origem_tag_map, destino_tag_map = {}, {}
            if transactions_df is not None and not transactions_df.empty:
                # Get last known non-'--' tag for each origin address from transactions
                tx_tags_orig = transactions_df[transactions_df['NomeOrigem'].notna() & (transactions_df['NomeOrigem'] != '--')].drop_duplicates(subset='Origem', keep='last').set_index('Origem')['NomeOrigem']
                # Get last known non-'--' tag for each destination address from transactions
                tx_tags_dest = transactions_df[transactions_df['NomeDestino'].notna() & (transactions_df['NomeDestino'] != '--')].drop_duplicates(subset='Destino', keep='last').set_index('Destino')['NomeDestino']
                origem_tag_map, destino_tag_map = tx_tags_orig.to_dict(), tx_tags_dest.to_dict()

            # Function to determine the final tag for an address
            def get_final_tag(addr):
                # Priority: 1. Tag from direct balance check (address_tags_map)
                tag = address_tags_map.get(addr)
                if tag and tag != '--': return tag
                # Priority: 2. Tag from transaction origin
                tag = origem_tag_map.get(addr)
                if tag and tag != '--': return tag
                # Priority: 3. Tag from transaction destination
                tag = destino_tag_map.get(addr)
                # Default to '--' if no valid tag found
                return tag if tag and tag != '--' else "--"

            # Apply the final tag logic to the balance DataFrame
            output_df['Tags'] = output_df['Endereço'].apply(get_final_tag)

            # --- Apply Tag Logic: Hide balance if tagged ---
            # Ensure 'Tags' column has no NaN values before comparison
            output_df['Tags'] = output_df['Tags'].fillna('--')
            # Create a mask for rows where a tag exists (is not '--')
            tagged_mask = output_df['Tags'] != '--'
            # For tagged addresses, replace Saldo and Ativo_Saldo with '--'
            output_df.loc[tagged_mask, ['Saldo', 'Ativo_Saldo']] = '--'
            print(f"Applied '--' balance masking to {tagged_mask.sum()} tagged addresses.")

            # Add 'Consultado' column marking original input addresses
            output_df = mark_original_addresses(output_df, original_addresses)

            # Define final column order and ensure all columns exist
            final_cols = ['Endereço', 'Saldo', 'Ativo_Saldo', 'Tags', 'Consultado']
            for col in final_cols:
                if col not in output_df.columns:
                    output_df[col] = None # Add missing columns if necessary
            output_df = output_df[final_cols] # Enforce order

            # Sort the final DataFrame: Original addresses first, then by address
            output_df = output_df.sort_values(by=['Consultado', 'Endereço'], ascending=[False, True])

            # Final deduplication after all processing (important after tag logic and adding missing)
            output_df = output_df.drop_duplicates(subset=['Endereço', 'Ativo_Saldo'], keep='first')

            # --- 6. Save Final Balance File ---
            try:
                output_df.to_excel(output_file_balances, index=False)
                print(f"Saved {len(output_df)} balance entries to {os.path.basename(output_file_balances)}")
            except Exception as e:
                raise IOError(f"Falha ao salvar o arquivo de saldos '{os.path.basename(output_file_balances)}': {e}")

            # --- 7. Cleanup and Final Message ---
            self._update_progress(status="Finalizando...", value=100, wallet="", overall="")
            # Clean up the temporary file
            try:
                if os.path.exists(temp_wallets_file):
                    os.remove(temp_wallets_file)
                    print(f"Removed temporary file: {os.path.basename(temp_wallets_file)}")
            except OSError as e:
                # Log warning if temp file removal fails, but don't stop
                print(f"Warning: Error removing temporary file '{os.path.basename(temp_wallets_file)}': {e}")

            # Prepare success message
            final_message = (
                f"Processamento concluído com sucesso!\n\n"
                f"Saldos salvos em:\n{output_file_balances}\n\n"
                f"Transações salvas em:\n{output_file_transactions}"
            )
            # Show success message via the main thread (which will trigger cleanup/close)
            self._show_final_message("Sucesso", final_message)

        except Exception as e:
            # --- Error Handling ---
            # Log the full error traceback to the console for debugging
            print(f"ERROR in processing thread: {type(e).__name__}: {e}")
            traceback.print_exc()
            # Prepare a user-friendly error message
            error_msg = f"Ocorreu um erro durante o processamento:\n\n{type(e).__name__}: {e}\n\nVerifique o console ou o log para detalhes técnicos."
            # Show error message via the main thread (which will trigger cleanup/close)
            self._show_final_message("Erro no Processamento", error_msg, is_error=True)
        finally:
             # Ensure temporary file is removed even if errors occurred mid-process
             try:
                 if os.path.exists(temp_wallets_file):
                     os.remove(temp_wallets_file)
                     print(f"Cleaned up temporary file: {os.path.basename(temp_wallets_file)}")
             except OSError as e:
                 print(f"Warning: Error removing temporary file during cleanup: {e}")


# --- Main Execution Guard ---
if __name__ == "__main__":
    # Check for required libraries before starting GUI
    try:
        import requests, pandas, openpyxl
    except ImportError as e:
        # Show error message if libraries are missing
        missing_lib = e.name
        error_msg = (f"Erro: Biblioteca necessária '{missing_lib}' não encontrada.\n\n"
                     f"Por favor, instale as bibliotecas necessárias executando:\n"
                     f"pip install requests pandas openpyxl\n\n"
                     f"Ou, se estiver usando um ambiente virtual, ative-o primeiro.")
        # Use Tkinter for the error message if possible, otherwise print to console
        try:
            root_check = tk.Tk()
            root_check.withdraw() # Hide the empty root window
            messagebox.showerror("Erro de Dependência", error_msg)
            root_check.destroy()
        except tk.TclError:
             print(error_msg) # Fallback to console if Tkinter fails early
        exit() # Exit the script

    # Create the main Tkinter window and run the application
    root = tk.Tk()
    app = TronScannerApp(root)
    root.mainloop()
