import requests
import datetime
import pandas as pd
from bs4 import BeautifulSoup
from decimal import Decimal
import urllib3

# Your Etherscan API key
your_api_key = "5D7PRGFBC1XWPEJIF36RTA1F3RRVUY7W72"

# Proxy settings (adjust as needed)
proxies = {
    'http': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080',
    'https': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080'
}

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'}

def fetch_eth_transactions(address):
    base_url = "https://api.etherscan.io/api"
    module = "account"
    action = "txlist"
    startblock = 0
    endblock = 99999999
    sort = "asc"
    apikey = your_api_key

    url = f"{base_url}?module={module}&action={action}&address={address}&startblock={startblock}&endblock={endblock}&sort={sort}&apikey={apikey}"

    try:
        response = requests.get(url, proxies=proxies, verify=False)
        response.raise_for_status()
        data = response.json()

        if data["status"] == "1":
            transactions = data["result"]

            for transaction in transactions:
                transaction_hash = transaction["hash"]

                # Construct Etherscan transaction URL
                transaction_url = f"https://etherscan.io/tx/{transaction_hash}"

                try:
                    response = requests.get(transaction_url, headers=headers, proxies=proxies, verify=False)
                    response.raise_for_status()
                    soup = BeautifulSoup(response.text, 'html.parser')

                    # Extract exchange information from the HTML
                    exchange_element = soup.select_one(".d-flex.flex-wrap.align-items-center span.text-nowrap.text-muted.me-1")
                    exchange_name = exchange_element.text.strip() if exchange_element else "--"

                    yield {
                        "block": transaction["blockNumber"],
                        "data-hora": datetime.datetime.fromtimestamp(int(transaction["timeStamp"])).strftime('%Y-%m-%d %H:%M:%S'),
                        "hashTransação": transaction_hash,
                        "CarteiraOrigem": transaction["from"],
                        "CarteiraDestino": transaction["to"],
                        "Valor (ETH)": convert_eth_value(transaction["value"]),
                        "exchange": exchange_name
                    }
                except requests.exceptions.RequestException as e:
                    if e.response.status_code == 403:
                        print(f"Transaction {transaction_hash} forbidden: Access denied.")
                    else:
                        print(f"Error fetching data for transaction {transaction_hash}: {e}")

        else:
            print(f"Error fetching transaction info for {address}: {data['message']}")
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data for {address}: {e}")

def convert_eth_value(value):
    """Converts wei value to Ether (ETH) with decimal places."""
    return Decimal(value) / (10**18)

def main():
    input_file = "input.xlsx"
    output_file = "etherscan_transactions.xlsx"

    addresses_df = pd.read_excel(input_file)
    all_transactions = []

    for _, row in addresses_df.iterrows():
        address = row['Endereços']
        transactions = fetch_eth_transactions(address)
        all_transactions.extend(transactions)

    transactions_df = pd.DataFrame(all_transactions)
    transactions_df.to_excel(output_file, index=False)

if __name__ == "__main__":
    main()