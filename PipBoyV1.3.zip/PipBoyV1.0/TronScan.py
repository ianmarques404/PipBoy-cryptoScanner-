import requests
import pandas as pd
import urllib3
import datetime
import os

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DadosConta:
    def __init__(self, endereco, tokens):
        self.endereco = endereco
        self.tokens = tokens  # List of tuples (token_name, balance, token_abbr)

    def __repr__(self):
        token_info = "\n".join(f"{nome} = {quantidade} ({abreviacao})"
                               for nome, quantidade, abreviacao in self.tokens)
        return (f"Dados Conta: \n"
                f"Endereço: {self.endereco}\n"
                f"Tokens:\n{token_info}")

def fetch_account_data(url):
    headers = {"accept": "application/json"}
    proxies = {
        'http': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080',
        'https': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080'
    }
    response = requests.get(url, headers=headers, proxies=proxies, verify=False)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Error fetching data: {response.status_code}")

def format_token_amount(amount, decimal):
    amount_int = int(amount)
    whole = str(amount_int // (10 ** decimal))
    fractional = str(amount_int % (10 ** decimal)).zfill(decimal)
    formatted_amount = f"{whole},{fractional}" if decimal > 0 else whole
    return formatted_amount.rstrip('0').rstrip(',') if ',' in formatted_amount else formatted_amount

def fetch_transaction_details(hash):
    url = f"https://apilist.tronscanapi.com/api/transaction-info?hash={hash}"
    proxies = {
        'http': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080',
        'https': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080'
    }
    response = requests.get(url, proxies=proxies, verify=False)
    if response.status_code == 200:
        data = response.json()

        origem = data.get("ownerAddress") or data.get("contractData", {}).get("owner_address")
        destino = data.get("toAddress") or data.get("trc20TransferInfo", [{}])[0].get("to_address") or \
                  data.get("tokenTransferInfo", {}).get("to_address") or \
                  data.get("transfersAllList", [{}])[0].get("to_address") or None

        address_tags = data.get("addressTag", {})
        nome_origem = address_tags.get(origem, "--") if origem else "--"
        nome_destino = address_tags.get(destino, "--") if destino else "--"

        if "trc20TransferInfo" in data:
            trc20_info = data["trc20TransferInfo"][0]
            nome = trc20_info.get("name", "TRC20 Token")
            symbol = trc20_info.get("symbol", "TRC20")
            decimals = trc20_info.get("decimals", 6)
            amount_str = trc20_info.get("amount_str", "0")
            formatted_quantia = format_token_amount(amount_str, decimals)
        elif "contractData" in data and "tokenInfo" in data["contractData"]:
            token_info = data["contractData"]["tokenInfo"]
            nome = token_info.get("tokenName", "Token")
            symbol = token_info.get("tokenAbbr", "TOKEN")
            decimals = token_info.get("tokenDecimal", 6)
            amount = data["contractData"].get("amount", 0)
            formatted_quantia = format_token_amount(str(amount), decimals)
        else:
            nome = "TRX"
            quantidade = int(data.get("contractData", {}).get("amount", 0)) / (10 ** 6)
            formatted_quantia = format_token_amount(str(int(quantidade * (10 ** 6))), 6)

        data_hora = datetime.datetime.fromtimestamp(data["timestamp"] / 1000).strftime('%Y-%m-%d %H:%M:%S')
        return {
            "Origem": origem,
            "NomeOrigem": nome_origem,
            "Destino": destino,
            "NomeDestino": nome_destino,
            "Hash": hash,
            "Nome": nome,
            "Quantia": formatted_quantia,
            "Data": data_hora,
            "Rede": "Tron"
        }
    return None

def fetch_wallet_transactions(wallet):
    transaction_data = []
    offset = 0
    limit = 50

    while True:
        url = f"https://apilist.tronscanapi.com/api/transaction?sort=-timestamp&count=true&limit={limit}&start={offset}&address={wallet}"
        proxies = {
            'http': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080',
            'https': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080'
        }
        response = requests.get(url, proxies=proxies, verify=False)

        if response.status_code != 200:
            break

        transactions = response.json().get("data", [])
        if not transactions:
            break

        for tx in transactions:
            tx_hash = tx.get("hash")
            tx_details = fetch_transaction_details(tx_hash)
            if tx_details:
                transaction_data.append(tx_details)

        offset += limit  # Move to the next batch of transactions

    return transaction_data

def create_temp_wallets_from_transactions(transactions_file):
    # Read the transactions file and extract unique addresses
    transactions_df = pd.read_excel(transactions_file)
    unique_addresses = set(transactions_df['Origem'].tolist() + transactions_df['Destino'].tolist())

    # Write the unique addresses to a new temp_wallets.xlsx file
    temp_wallets_df = pd.DataFrame(list(unique_addresses), columns=['Endereços'])
    temp_wallets_df.to_excel('temp_wallets.xlsx', index=False)

def main():
    input_file = "input.xlsx"
    output_file = "output.xlsx"
    transactions_file = "Transacoes.xlsx"
    temp_wallets_file = "temp_wallets.xlsx"

    # Step 1: Fetch transaction details and create Transacoes.xlsx
    addresses_df = pd.read_excel(input_file)
    all_transactions = []

    for _, row in addresses_df.iterrows():
        address = row['Endereços']
        wallet_transactions = fetch_wallet_transactions(address)
        all_transactions.extend(wallet_transactions)

    transactions_df = pd.DataFrame(all_transactions, columns=["Origem", "NomeOrigem", "Destino", "NomeDestino", "Hash", "Nome", "Quantia", "Data", "Rede"])
    transactions_df.to_excel(transactions_file, index=False)

    # Step 2: Create temp_wallets.xlsx from the generated Transacoes.xlsx
    create_temp_wallets_from_transactions(transactions_file)

    # Step 3: Process wallet information from temp_wallets.xlsx
    temp_wallets_df = pd.read_excel(temp_wallets_file)
    results = []
    
    for _, row in temp_wallets_df.iterrows():
        address = row['Endereços']

        # Skip addresses that are exchange-owned (i.e., have non- "--" in NomeOrigem or NomeDestino)
        transactions = transactions_df[
            ((transactions_df['Origem'] == address) & (transactions_df['NomeOrigem'] != '--')) |
            ((transactions_df['Destino'] == address) & (transactions_df['NomeDestino'] != '--'))
        ]
        
        if not transactions.empty:
            continue  # Skip if this address is exchange-owned

        url = f"https://apilist.tronscanapi.com/api/account?address={address}&limit=9999"
        
        account_data = fetch_account_data(url)
        tokens = account_data.get('tokens', [])
        
        token_info_list = []
        for token in tokens:
            token_name = token.get('tokenName', '')
            token_abbr = token.get('tokenAbbr', '').upper()
            balance = format_token_amount(token.get('balance', 0), token.get('tokenDecimal', 0))
            token_info_list.append((token_name, balance, token_abbr))

        results.append(DadosConta(endereco=address, tokens=token_info_list))

    # Create DataFrame for results (excluding exchange-owned addresses)
    rows = []
    for dados in results:
        for token_info in dados.tokens:
            rows.append([dados.endereco, *token_info])

    output_df = pd.DataFrame(rows, columns=['Endereço', 'Token Nome', 'Saldo', 'Token Abreviação'])
    output_df.to_excel(output_file, index=False)

    # Clean up temp file
    os.remove(temp_wallets_file)  # Delete the temporary wallet file

if __name__ == "__main__":
    main()
