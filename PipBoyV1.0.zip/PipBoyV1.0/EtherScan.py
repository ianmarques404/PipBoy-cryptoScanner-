import requests
import pandas as pd
from decimal import Decimal
import urllib3
import datetime

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Your Etherscan API key
your_api_key = "5D7PRGFBC1XWPEJIF36RTA1F3RRVUY7W72"

# Proxy settings (adjust as needed)
proxies = {
    'http': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080',
    'https': 'http://ian.imgm:Otorrinolaringologista10@@proxy.dpf.gov.br:8080'
}

def fetch_eth_transactions(address):
    base_url = "https://api.etherscan.io/api"
    module = "account"
    action = "txlist"
    startblock = 0
    endblock = 99999999
    sort = "asc"
    apikey = your_api_key

    url = f"{base_url}?module={module}&action={action}&address={address}&startblock={startblock}&endblock={endblock}&sort={sort}&apikey={apikey}"

    try:
        response = requests.get(url, proxies=proxies, verify=False)
        response.raise_for_status()
        data = response.json()

        if data["status"] == "1":
            transactions = data["result"]
            for transaction in transactions:
                value_eth = convert_eth_value(transaction["value"])
                timestamp = transaction["timeStamp"]
                date_time = datetime.datetime.fromtimestamp(int(timestamp))
                formatted_date = date_time.strftime('%Y-%m-%d %H:%M:%S')
                yield {
                    "blockNumber": transaction["blockNumber"],
                    "timeStamp": formatted_date,
                    "hash": transaction["hash"],
                    "from": transaction["from"],
                    "to": transaction["to"],
                    "value (ETH)": value_eth,
                    # ... Include other relevant fields as needed
                }
        else:
            print(f"Error fetching transaction info for {address}: {data['message']}")
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data for {address}: {e}")

def convert_eth_value(value):
    """Converts wei value to Ether (ETH) with decimal places."""
    return Decimal(value) / (10**18)

def main():
    input_file = "input.xlsx"
    output_file = "etherscan_transactions.xlsx"

    addresses_df = pd.read_excel(input_file)
    all_transactions = []

    for _, row in addresses_df.iterrows():
        address = row['Endereços']
        transactions = fetch_eth_transactions(address)
        all_transactions.extend(transactions)

    transactions_df = pd.DataFrame(all_transactions)
    transactions_df.to_excel(output_file, index=False)

if __name__ == "__main__":
    main()