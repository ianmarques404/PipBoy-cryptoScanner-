import requests
import pandas as pd
import urllib3
import datetime
import os
import tkinter as tk
from tkinter import simpledialog, messagebox

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DadosConta:
    def __init__(self, endereco, tokens, address_tag):
        self.endereco = endereco
        self.tokens = tokens  # List of tuples (token_name, balance, token_abbr)
        self.address_tag = address_tag

    def __repr__(self):
        token_info = "\n".join(f"{nome} = {quantidade} ({abreviacao})"
                               for nome, quantidade, abreviacao in self.tokens)
        return (f"Dados Conta: \n"
                f"Endereço: {self.endereco}\n"
                f"Tags: {self.address_tag}\n"
                f"Tokens:\n{token_info}")

def fetch_account_data(url, proxies):
    headers = {"accept": "application/json"}
    response = requests.get(url, headers=headers, proxies=proxies, verify=False)
    if response.status_code == 200:
        data = response.json()
        address_tag = data.get("address_tag", "")
        return data, address_tag
    else:
        raise Exception(f"Error fetching data: {response.status_code}")

def format_token_amount(amount, decimal):
    amount_int = int(amount)
    whole = str(amount_int // (10 ** decimal))
    fractional = str(amount_int % (10 ** decimal)).zfill(decimal)
    formatted_amount = f"{whole},{fractional}" if decimal > 0 else whole
    return formatted_amount.rstrip('0').rstrip(',') if ',' in formatted_amount else formatted_amount

def fetch_transaction_details(hash, proxies):
    url = f"https://apilist.tronscanapi.com/api/transaction-info?hash={hash}"
    response = requests.get(url, proxies=proxies, verify=False)
    if response.status_code == 200:
        data = response.json()
        origem = data.get("ownerAddress") or data.get("contractData", {}).get("owner_address")
        destino = data.get("trc20TransferInfo", [{}])[0].get("to_address") or \
          data.get("tokenTransferInfo", {}).get("to_address") or \
          data.get("transfersAllList", [{}])[0].get("to_address") or \
          data.get("toAddress") or None


        address_tags = data.get("addressTag", {})
        nome_origem = address_tags.get(origem, "--") if origem else "--"
        nome_destino = address_tags.get(destino, "--") if destino else "--"

        if "trc20TransferInfo" in data:
            trc20_info = data["trc20TransferInfo"][0]
            nome = trc20_info.get("name", "TRC20 Token")
            symbol = trc20_info.get("symbol", "TRC20")
            decimals = trc20_info.get("decimals", 6)
            amount_str = trc20_info.get("amount_str", "0")
            formatted_quantia = format_token_amount(amount_str, decimals)
            if symbol.upper() in ("TRX", "USDT"):
                return {
                    "Origem": origem,
                    "NomeOrigem": nome_origem,
                    "Destino": destino,
                    "NomeDestino": nome_destino,
                    "Hash": hash,
                    "Ativo_Transacoes": nome,
                    "Quantidade": formatted_quantia,
                    "Data": datetime.datetime.fromtimestamp(data["timestamp"] / 1000).strftime('%Y-%m-%d %H:%M:%S'),
                    "Rede": "Tron"
                }
        else:
            nome = "TRX"
            quantidade = int(data.get("contractData", {}).get("amount", 0)) / (10 ** 6)
            formatted_quantia = format_token_amount(str(int(quantidade * (10 ** 6))), 6)
            return {
                "Origem": origem,
                "NomeOrigem": nome_origem,
                "Destino": destino,
                "NomeDestino": nome_destino,
                "Hash": hash,
                "Ativo_Transacoes": nome,
                "Quantidade": formatted_quantia,
                "Data": datetime.datetime.fromtimestamp(data["timestamp"] / 1000).strftime('%Y-%m-%d %H:%M:%S'),
                "Rede": "Tron"
            }
    return None

def fetch_wallet_transactions(wallet, proxies):
    transaction_data = []
    offset = 0
    limit = 300

    while True:
        url = f"https://apilist.tronscanapi.com/api/transaction?sort=-timestamp&count=true&limit={limit}&start={offset}&address={wallet}"
        response = requests.get(url, proxies=proxies, verify=False)

        if response.status_code != 200:
            break

        transactions = response.json().get("data", [])
        if not transactions:
            break

        for tx in transactions:
            tx_hash = tx.get("hash")
            tx_details = fetch_transaction_details(tx_hash, proxies)
            if tx_details:
                transaction_data.append(tx_details)

        offset += limit  # Move to the next batch of transactions

    return transaction_data

def create_temp_wallets_from_transactions(transactions_file, original_addresses):
    transactions_df = pd.read_excel(transactions_file)
    unique_addresses = set(transactions_df['Origem'].tolist() + transactions_df['Destino'].tolist())
    # Filter out original addresses
    unique_addresses = unique_addresses - original_addresses
    temp_wallets_df = pd.DataFrame(list(unique_addresses), columns=['Endereços'])
    temp_wallets_df.to_excel('temp_wallets.xlsx', index=False)

def mark_original_addresses(df, original_addresses):
    df['Consultado'] = df['Endereço'].apply(lambda x: "Sim" if x in original_addresses else "Não")
    return df

def create_progress_window():
    """Creates a progress window with a text field and progress bar."""
    progress_window = tk.Tk()
    progress_window.title("Processando Endereços")
    progress_window.geometry("400x150")

    label = tk.Label(progress_window, text="Processando Endereço: ", font=("Arial", 12))
    label.pack(pady=10)

    wallet_label = tk.Label(progress_window, text="", font=("Arial", 10), wraplength=380)
    wallet_label.pack(pady=5)

    progress_bar = tk.DoubleVar()
    progress = tk.Scale(
        progress_window, variable=progress_bar, from_=0, to=100, orient="horizontal",
        length=350, label="Progresso", showvalue=False
    )
    progress.pack(pady=10)

    return progress_window, wallet_label, progress_bar

def process_account_balances(address, account_data, proxies):
    """Processes account balances for a given address, excluding contract addresses."""

    is_contract = 'contractMap' in account_data and account_data['contractMap'].get(address, False)
    if not is_contract:
        tokens = account_data.get('tokens', [])
        token_info_list = []
        for token in tokens:
            token_name = token.get('tokenName', '')
            token_abbr = token.get('tokenAbbr', '').upper()
            balance = format_token_amount(token.get('balance', 0), token.get('tokenDecimal', 0))
            if token_abbr in ("TRX", "USDT"):  # Filter for TRX and USDT
                token_info_list.append((token_name, balance, token_abbr))
        return DadosConta(endereco=address, tokens=token_info_list, address_tag="")  # Return DadosConta object
    return None  # Return None if it's a contract address

def main():
    input_file = "input.xlsx"
    output_file = "Saldo.xlsx"
    transactions_file = "Transacoes.xlsx"
    temp_wallets_file = "temp_wallets.xlsx"

    # GUI for proxy user input
    root = tk.Tk()
    root.withdraw()

    while True:
        proxy_user = simpledialog.askstring("Credenciais do Proxy", "Insira seu Usuário:")
        proxy_user_id = simpledialog.askstring("Credenciais do Proxy", "Insira sua Senha:")

        if not proxy_user or not proxy_user_id:
            if not messagebox.askokcancel("Erro", "Usuário e Senha do Proxy São Necessárias. Tente Novamente."):
                return
        else:
            break

    proxy_url = f"http://{proxy_user}:{proxy_user_id}@proxy.dpf.gov.br:8080"
    proxies = {
        'http': proxy_url,
        'https': proxy_url
    }

    # Read input file and remove duplicates
    addresses_df = pd.read_excel(input_file)
    addresses_df = addresses_df.drop_duplicates(subset=['Endereços'])  # Remove duplicate addresses
    original_addresses = set(addresses_df['Endereços'].tolist())  # Track original addresses
    total_wallets = len(addresses_df)
    all_transactions = []
    results = []  # Initialize results list

    # Track processed addresses to avoid duplicates
    processed_addresses = set()

    # Create progress window
    progress_window, wallet_label, progress_bar = create_progress_window()
    progress_window.update()

    # Process original addresses
    for i, (_, row) in enumerate(addresses_df.iterrows(), 1):
        address = row['Endereços']
        if address in processed_addresses:
            continue  # Skip if already processed
        processed_addresses.add(address)  # Mark as processed

        wallet_label.config(text=f"{address} ({i} de {total_wallets})")
        progress_bar.set((i / total_wallets) * 100)
        progress_window.update_idletasks()

        wallet_transactions = fetch_wallet_transactions(address, proxies)
        all_transactions.extend(wallet_transactions)

        url = f"https://apilist.tronscanapi.com/api/account?address={address}&limit=9999"
        account_data_tuple = fetch_account_data(url, proxies)
        account_data = account_data_tuple[0]

        account_data_for_balance = account_data.copy()  # Create a copy
        dados_conta = process_account_balances(address, account_data_for_balance, proxies)
        if dados_conta:
            results.append(dados_conta)

    transactions_df = pd.DataFrame(all_transactions, columns=["Origem", "NomeOrigem", "Destino", "NomeDestino", "Hash", "Ativo_Transacoes", "Quantidade", "Data", "Rede"])
    transactions_df.to_excel(transactions_file, index=False)

    create_temp_wallets_from_transactions(transactions_file, original_addresses)

    # Process related addresses
    temp_wallets_df = pd.read_excel(temp_wallets_file)
    for i, (_, row) in enumerate(temp_wallets_df.iterrows(), 1):
        address = row['Endereços']
        if address in processed_addresses:
            continue  # Skip if already processed
        processed_addresses.add(address)  # Mark as processed

        wallet_label.config(text=f"{address} (Endereço Relacionado {i})")
        progress_window.update_idletasks()

        url = f"https://apilist.tronscanapi.com/api/account?address={address}&limit=9999"
        account_data_tuple = fetch_account_data(url, proxies)
        account_data = account_data_tuple[0]

        account_data_for_balance = account_data.copy()  # Create a copy
        dados_conta = process_account_balances(address, account_data_for_balance, proxies)
        if dados_conta:
            results.append(dados_conta)

    # Prepare final output
    rows = []
    for dados in results:
        for token_info in dados.tokens:
            rows.append([dados.endereco, token_info[1], token_info[2]])

    output_df = pd.DataFrame(rows, columns=['Endereço', 'Saldo', 'Ativo_Saldo'])

    # Mark original addresses
    output_df = mark_original_addresses(output_df, original_addresses)

    # Merge tags
    output_df = output_df.merge(
        transactions_df[['Origem', 'NomeOrigem']].drop_duplicates(subset='Origem').rename(columns={'Origem': 'Endereço', 'NomeOrigem': 'Tags'}),
        on='Endereço', how='left'
    )
    output_df = output_df.merge(
        transactions_df[['Destino', 'NomeDestino']].drop_duplicates(subset='Destino').rename(columns={'Destino': 'Endereço', 'NomeDestino': 'Tags'}),
        on='Endereço', how='left'
    )

    if 'Tags_x' in output_df.columns and 'Tags_y' in output_df.columns:
        output_df['Tags'] = output_df['Tags_x'].fillna(output_df['Tags_y'])
        output_df = output_df.drop(columns=['Tags_x', 'Tags_y'])
    elif 'Tags_x' in output_df.columns:
        output_df['Tags'] = output_df['Tags_x']
        output_df = output_df.drop(columns=['Tags_x'])
    elif 'Tags_y' in output_df.columns:
        output_df['Tags'] = output_df['Tags_y']
        output_df = output_df.drop(columns=['Tags_y'])
    else:
        output_df['Tags'] = None

    output_df.loc[output_df['Tags'].astype(str) != '--', ['Saldo', 'Ativo_Saldo']] = 'N/A'

    # Remove duplicates in the final output
    output_df = output_df.drop_duplicates(subset=['Endereço', 'Ativo_Saldo'])  # Ensure no duplicates
    output_df.to_excel(output_file, index=False)

    # Mark original addresses in transactions file
    transactions_df['Original Origem'] = transactions_df['Origem'].apply(lambda x: "Sim" if x in original_addresses else "Não")
    transactions_df['Original Destino'] = transactions_df['Destino'].apply(lambda x: "Sim" if x in original_addresses else "Não")
    transactions_df = transactions_df[transactions_df['NomeOrigem'] == '--']
    transactions_df.to_excel(transactions_file, index=False)

    # Clean up temporary files
    os.remove(temp_wallets_file)
    progress_window.destroy()

if __name__ == "__main__":
    main()